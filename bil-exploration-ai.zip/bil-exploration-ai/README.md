# BIL EXPLORATION AI

Multi-AI workflow orchestration platform — MVP scaffold (Milestones 1–3 of the roadmap: foundation, provider layer, engine v0). See `BIL_EXPLORATION_AI_SPEC.md` and `AGENTS.md` for full design and rules.

## What's implemented in this scaffold

- `packages/ai-core` — the provider-agnostic `AIProvider` interface + `AIRouter`
- `packages/providers` — working adapters for OpenAI, Anthropic, Google Gemini, Ollama, plus a factory for DeepSeek/OpenRouter/any OpenAI-compatible endpoint
- `packages/workflow-engine` — DAG executor with parallel levels, retry, timeout
- `packages/workflow-nodes` — `input`, `output`, `ai` node handlers
- `packages/database` — Prisma schema matching the spec's DB design, plus a seed script
- `apps/api` — Fastify API: auth, provider test/credentials, workflow CRUD + versioning, SSE-streamed execution, execution logs
- `apps/cli` — thin CLI (`bil login`, `bil provider list/test`, `bil workflow run`, `bil logs`)
- `docker-compose.yml` — Postgres + API, ready for a single VPS

Not yet implemented (see the spec's "Future" sections): the React Flow web builder UI, tool/http/condition/loop nodes, the agent engine, teams/permissions, and the worker/queue split.

## Local setup

```bash
cp .env.example .env      # fill in BIL_JWT_SECRET and BIL_MASTER_KEY with random strings
npm install
npm run db:generate --workspace=@bil/database
npm run db:migrate --workspace=@bil/database
npx tsx packages/database/prisma/seed.ts   # registers the built-in providers

npm run build              # builds all packages
npm run dev:api             # starts the API on :4000
```

## Try it end to end

```bash
# 1. Sign up
curl -X POST localhost:4000/auth/signup -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"supersecret"}'
# → copy the returned token

# 2. Store a BYOK key for a provider (e.g. OpenAI)
curl -X POST localhost:4000/providers/openai/credentials \
  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \
  -d '{"apiKey":"sk-..."}'

# 3. Create a project directly in the DB for now (no project UI yet),
#    then create a two-node workflow: input -> ai -> output
curl -X POST localhost:4000/workflows -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d '{
  "projectId": "<project-id>",
  "name": "Hello AI",
  "graph": {
    "nodes": [
      { "id": "in", "type": "input", "name": "Input", "config": {} },
      { "id": "ai1", "type": "ai", "name": "GPT", "config": { "provider": "openai", "model": "gpt-4o-mini" } },
      { "id": "out", "type": "output", "name": "Output", "config": {} }
    ],
    "edges": [{ "from": "in", "to": "ai1" }, { "from": "ai1", "to": "out" }]
  }
}'

# 4. Run it (streams Server-Sent Events)
curl -N -X POST localhost:4000/workflows/<workflow-id>/run \
  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \
  -d '{"input":"Say hello in one sentence."}'
```

## VPS deployment

```bash
cp .env.example .env   # fill in real secrets
docker compose up -d --build
```

## Adding a new AI provider

See `AGENTS.md` — implement `AIProvider` in `packages/providers/src/<name>/`, register it in `packages/providers/src/index.ts`, add a row via the seed script. Nothing in the engine, nodes, or API changes.
