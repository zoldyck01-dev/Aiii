#!/usr/bin/env node
// apps/cli/src/index.ts
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const CONFIG_DIR = join(homedir(), ".bil");
const CONFIG_PATH = join(CONFIG_DIR, "config.json");

interface CliConfig {
  apiUrl: string;
  token?: string;
}

function loadConfig(): CliConfig {
  if (!existsSync(CONFIG_PATH)) return { apiUrl: process.env.BIL_API_URL ?? "http://localhost:4000" };
  return JSON.parse(readFileSync(CONFIG_PATH, "utf8"));
}

function saveConfig(config: CliConfig) {
  mkdirSync(CONFIG_DIR, { recursive: true });
  writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
}

async function api(path: string, options: RequestInit = {}) {
  const config = loadConfig();
  const res = await fetch(`${config.apiUrl}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(config.token ? { Authorization: `Bearer ${config.token}` } : {}),
      ...options.headers,
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API error ${res.status}: ${body}`);
  }
  return res;
}

async function main() {
  const [, , command, ...args] = process.argv;

  switch (command) {
    case "login": {
      const [email, password] = args;
      if (!email || !password) return console.error("Usage: bil login <email> <password>");
      const res = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      const data = await res.json();
      const config = loadConfig();
      saveConfig({ ...config, token: data.token });
      console.log("Logged in.");
      break;
    }

    case "provider": {
      const [sub, providerKey] = args;
      if (sub === "list") {
        const res = await api("/providers");
        console.log(JSON.stringify(await res.json(), null, 2));
      } else if (sub === "test" && providerKey) {
        const res = await api(`/providers/${providerKey}/test`, { method: "POST" });
        console.log(JSON.stringify(await res.json(), null, 2));
      } else {
        console.error("Usage: bil provider list | bil provider test <key>");
      }
      break;
    }

    case "workflow": {
      const [sub, workflowId] = args;
      if (sub === "run" && workflowId) {
        const inputFlagIndex = args.indexOf("--input");
        const input = inputFlagIndex >= 0 ? args[inputFlagIndex + 1] : "";
        const config = loadConfig();
        const res = await fetch(`${config.apiUrl}/workflows/${workflowId}/run`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${config.token}` },
          body: JSON.stringify({ input }),
        });
        if (!res.body) return console.error("No response stream from server");
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        // Server-Sent Events: print each event as it streams in.
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          process.stdout.write(decoder.decode(value));
        }
      } else {
        console.error("Usage: bil workflow run <id> --input \"...\"");
      }
      break;
    }

    case "logs": {
      const [executionId] = args;
      if (!executionId) return console.error("Usage: bil logs <executionId>");
      const res = await api(`/executions/${executionId}/logs`);
      console.log(JSON.stringify(await res.json(), null, 2));
      break;
    }

    default:
      console.log(`BIL EXPLORATION AI CLI

Usage:
  bil login <email> <password>
  bil provider list
  bil provider test <key>
  bil workflow run <id> --input "..."
  bil logs <executionId>
`);
  }
}

main().catch((err) => {
  console.error(err.message ?? err);
  process.exit(1);
});
