// apps/api/src/lib/credential-resolver.ts
import type { CredentialResolver } from "@bil/ai-core";
import { prisma } from "./db.js";
import { decryptSecret } from "./vault.js";

/**
 * Resolution order per provider: org-level BYOK credential, then
 * user-level BYOK, then a platform-managed key from env (BIL_PLATFORM_<PROVIDER>_KEY).
 * This is the only place in the codebase allowed to decrypt a stored key.
 */
export const resolveCredential: CredentialResolver = async (providerId, scope) => {
  const provider = await prisma.aiProviderDef.findUnique({ where: { key: providerId } });
  if (!provider) throw new Error(`Unknown provider "${providerId}"`);

  const credential = await prisma.apiCredential.findFirst({
    where: {
      providerId: provider.id,
      OR: [
        scope.orgId ? { orgId: scope.orgId } : undefined,
        scope.userId ? { userId: scope.userId } : undefined,
      ].filter(Boolean) as object[],
    },
    orderBy: { createdAt: "desc" },
  });

  if (credential?.source === "BYOK" && credential.encryptedKey) {
    return { apiKey: decryptSecret(credential.encryptedKey), baseUrl: credential.baseUrl ?? undefined };
  }
  if (credential?.source === "ENV" || !credential) {
    const envKey = process.env[`BIL_PLATFORM_${providerId.toUpperCase()}_KEY`];
    if (envKey) return { apiKey: envKey, baseUrl: credential?.baseUrl ?? provider.baseUrl ?? undefined };
  }
  if (credential?.source === "PLATFORM" && credential.encryptedKey) {
    return { apiKey: decryptSecret(credential.encryptedKey), baseUrl: credential.baseUrl ?? undefined };
  }

  // Ollama/local providers may need no key at all — return baseUrl only.
  return { baseUrl: provider.baseUrl ?? undefined };
};
