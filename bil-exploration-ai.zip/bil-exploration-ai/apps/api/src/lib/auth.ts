// apps/api/src/lib/auth.ts
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

function jwtSecret(): string {
  const secret = process.env.BIL_JWT_SECRET;
  if (!secret) throw new Error("BIL_JWT_SECRET must be set (see .env.example)");
  return secret;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function signToken(userId: string): string {
  return jwt.sign({ sub: userId }, jwtSecret(), { expiresIn: "7d" });
}

export function verifyToken(token: string): { userId: string } {
  const payload = jwt.verify(token, jwtSecret()) as { sub: string };
  return { userId: payload.sub };
}
