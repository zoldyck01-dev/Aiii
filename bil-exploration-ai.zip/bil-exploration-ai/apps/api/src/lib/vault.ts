// apps/api/src/lib/vault.ts
// Encrypts/decrypts BYOK and platform API keys at rest using AES-256-GCM.
// The master key (BIL_MASTER_KEY) should come from a real KMS/secret
// manager in production — env var is fine for MVP/self-hosted.
import crypto from "node:crypto";

const ALGO = "aes-256-gcm";

function masterKey(): Buffer {
  const raw = process.env.BIL_MASTER_KEY;
  if (!raw || raw.length < 32) {
    throw new Error("BIL_MASTER_KEY must be set to a 32+ byte secret (see .env.example)");
  }
  return crypto.createHash("sha256").update(raw).digest(); // normalize to 32 bytes
}

export function encryptSecret(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, masterKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // store iv + authTag + ciphertext together, base64
  return Buffer.concat([iv, authTag, encrypted]).toString("base64");
}

export function decryptSecret(payload: string): string {
  const raw = Buffer.from(payload, "base64");
  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const ciphertext = raw.subarray(28);
  const decipher = crypto.createDecipheriv(ALGO, masterKey(), iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
}
