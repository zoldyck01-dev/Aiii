// apps/api/src/lib/require-auth.ts
import type { FastifyRequest, FastifyReply } from "fastify";
import { verifyToken } from "./auth.js";

declare module "fastify" {
  interface FastifyRequest {
    userId?: string;
  }
}

export async function requireAuth(req: FastifyRequest, reply: FastifyReply) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return reply.status(401).send({ error: "Missing bearer token" });
  }
  try {
    const { userId } = verifyToken(header.slice(7));
    req.userId = userId;
  } catch {
    return reply.status(401).send({ error: "Invalid or expired token" });
  }
}
