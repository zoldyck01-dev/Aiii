// apps/api/src/server.ts
import Fastify from "fastify";
import cors from "@fastify/cors";
import { AIRouter } from "@bil/ai-core";
import { builtInProviders } from "@bil/providers";
import { resolveCredential } from "./lib/credential-resolver.js";
import { authRoutes } from "./routes/auth.js";
import { providerRoutes } from "./routes/providers.js";
import { workflowRoutes } from "./routes/workflows.js";

async function main() {
  const app = Fastify({ logger: true });
  await app.register(cors, { origin: true });

  const router = new AIRouter(resolveCredential);
  for (const provider of builtInProviders()) router.register(provider);

  app.get("/health", async () => ({ ok: true, providers: router.listRegisteredProviders() }));

  await app.register(authRoutes);
  await app.register(providerRoutes, { router });
  await app.register(workflowRoutes, { router });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: "0.0.0.0" });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
