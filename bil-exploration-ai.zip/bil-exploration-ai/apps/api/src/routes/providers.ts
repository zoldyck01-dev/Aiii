// apps/api/src/routes/providers.ts
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../lib/db.js";
import { requireAuth } from "../lib/require-auth.js";
import { encryptSecret } from "../lib/vault.js";
import type { AIRouter } from "@bil/ai-core";

const credentialSchema = z.object({
  apiKey: z.string().optional(),
  baseUrl: z.string().url().optional(),
});

export async function providerRoutes(app: FastifyInstance, opts: { router: AIRouter }) {
  app.get("/providers", async () => {
    return prisma.aiProviderDef.findMany({ include: { models: true } });
  });

  app.post("/providers/:key/test", { preHandler: requireAuth }, async (req, reply) => {
    const { key } = req.params as { key: string };
    try {
      const health = await opts.router.healthCheck(key, { userId: req.userId });
      const models = health.ok ? await opts.router.listModels(key, { userId: req.userId }) : [];
      return reply.send({ health, models });
    } catch (err) {
      return reply.status(400).send({ error: (err as Error).message });
    }
  });

  app.post("/providers/:key/credentials", { preHandler: requireAuth }, async (req, reply) => {
    const { key } = req.params as { key: string };
    const body = credentialSchema.parse(req.body);
    const provider = await prisma.aiProviderDef.findUnique({ where: { key } });
    if (!provider) return reply.status(404).send({ error: `Unknown provider "${key}"` });

    const credential = await prisma.apiCredential.create({
      data: {
        providerId: provider.id,
        userId: req.userId,
        source: "BYOK",
        encryptedKey: body.apiKey ? encryptSecret(body.apiKey) : null,
        baseUrl: body.baseUrl,
      },
    });
    // Never return the key or its encrypted form.
    return reply.send({ id: credential.id, providerId: provider.id, source: credential.source });
  });
}
