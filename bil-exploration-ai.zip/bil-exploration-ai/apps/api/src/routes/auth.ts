// apps/api/src/routes/auth.ts
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../lib/db.js";
import { hashPassword, verifyPassword, signToken } from "../lib/auth.js";

const credentialsSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export async function authRoutes(app: FastifyInstance) {
  app.post("/auth/signup", async (req, reply) => {
    const body = credentialsSchema.parse(req.body);
    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) return reply.status(409).send({ error: "Email already registered" });

    const user = await prisma.user.create({
      data: { email: body.email, passwordHash: await hashPassword(body.password) },
    });
    return reply.send({ token: signToken(user.id), userId: user.id });
  });

  app.post("/auth/login", async (req, reply) => {
    const body = credentialsSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: body.email } });
    if (!user || !(await verifyPassword(body.password, user.passwordHash))) {
      return reply.status(401).send({ error: "Invalid email or password" });
    }
    return reply.send({ token: signToken(user.id), userId: user.id });
  });
}
