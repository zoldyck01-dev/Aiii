// apps/api/src/routes/workflows.ts
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../lib/db.js";
import { requireAuth } from "../lib/require-auth.js";
import { WorkflowExecutor, type WorkflowGraph } from "@bil/workflow-engine";
import { createDefaultRegistry } from "@bil/workflow-nodes";
import type { AIRouter } from "@bil/ai-core";

const graphNodeSchema = z.object({
  id: z.string(),
  type: z.enum(["input", "output", "ai", "tool", "http", "condition", "loop"]),
  name: z.string(),
  config: z.record(z.unknown()),
});
const graphSchema = z.object({
  nodes: z.array(graphNodeSchema),
  edges: z.array(z.object({ from: z.string(), to: z.string(), when: z.string().optional() })),
});

const createWorkflowSchema = z.object({
  projectId: z.string().uuid(),
  name: z.string().min(1),
  graph: graphSchema,
});

async function assertProjectAccess(userId: string, projectId: string) {
  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) throw { status: 404, message: "Project not found" };
  const membership = await prisma.orgMember.findUnique({
    where: { userId_orgId: { userId, orgId: project.orgId } },
  });
  if (!membership) throw { status: 403, message: "Not a member of this project's organization" };
  return project;
}

export async function workflowRoutes(app: FastifyInstance, opts: { router: AIRouter }) {
  const registry = createDefaultRegistry(opts.router);
  const executor = new WorkflowExecutor(registry, { maxRetries: 1, nodeTimeoutMs: 60_000 });

  app.post("/workflows", { preHandler: requireAuth }, async (req, reply) => {
    const body = createWorkflowSchema.parse(req.body);
    await assertProjectAccess(req.userId!, body.projectId).catch((e) => reply.status(e.status).send({ error: e.message }));

    const workflow = await prisma.workflow.create({
      data: { name: body.name, projectId: body.projectId },
    });
    const version = await prisma.workflowVersion.create({
      data: { workflowId: workflow.id, versionNumber: 1, graph: body.graph },
    });
    await prisma.workflow.update({ where: { id: workflow.id }, data: { latestVersionId: version.id } });
    return reply.send({ workflowId: workflow.id, versionId: version.id });
  });

  app.get("/workflows/:id", { preHandler: requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const workflow = await prisma.workflow.findUnique({ where: { id }, include: { versions: true } });
    if (!workflow) return reply.status(404).send({ error: "Workflow not found" });
    return reply.send(workflow);
  });

  app.put("/workflows/:id", { preHandler: requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const body = z.object({ graph: graphSchema }).parse(req.body);
    const workflow = await prisma.workflow.findUnique({ where: { id }, include: { versions: true } });
    if (!workflow) return reply.status(404).send({ error: "Workflow not found" });

    const nextVersionNumber = Math.max(0, ...workflow.versions.map((v) => v.versionNumber)) + 1;
    const version = await prisma.workflowVersion.create({
      data: { workflowId: id, versionNumber: nextVersionNumber, graph: body.graph },
    });
    await prisma.workflow.update({ where: { id }, data: { latestVersionId: version.id } });
    return reply.send({ versionId: version.id, versionNumber: nextVersionNumber });
  });

  app.post("/workflows/:id/run", { preHandler: requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const body = z.object({ input: z.unknown() }).parse(req.body);

    const workflow = await prisma.workflow.findUnique({ where: { id } });
    if (!workflow?.latestVersionId) return reply.status(404).send({ error: "Workflow has no version to run" });
    const version = await prisma.workflowVersion.findUnique({ where: { id: workflow.latestVersionId } });
    if (!version) return reply.status(404).send({ error: "Workflow version not found" });

    const execution = await prisma.execution.create({
      data: { workflowVersionId: version.id, input: body.input as object, triggeredBy: req.userId, status: "RUNNING" },
    });

    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });
    const send = (event: string, data: unknown) =>
      reply.raw.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

    try {
      const result = await executor.run(execution.id, version.graph as unknown as WorkflowGraph, body.input, {
        userId: req.userId,
      });

      for (const nodeResult of result.nodeResults) {
        await prisma.executionLog.create({
          data: {
            executionId: execution.id,
            nodeId: nodeResult.nodeId,
            output: nodeResult.output as object,
            tokensIn: nodeResult.tokensIn,
            tokensOut: nodeResult.tokensOut,
            costUsd: nodeResult.costUsd,
            latencyMs: nodeResult.latencyMs,
            error: nodeResult.error,
            retryCount: nodeResult.retryCount,
          },
        });
        send("node_complete", nodeResult);
      }

      await prisma.execution.update({
        where: { id: execution.id },
        data: {
          status: result.status === "success" ? "SUCCESS" : result.status === "partial" ? "PARTIAL" : "ERROR",
          output: result.finalOutput as object,
          endedAt: new Date(),
        },
      });
      send("execution_complete", { executionId: execution.id, status: result.status, output: result.finalOutput });
    } catch (err) {
      await prisma.execution.update({
        where: { id: execution.id },
        data: { status: "ERROR", endedAt: new Date() },
      });
      send("execution_error", { error: (err as Error).message });
    } finally {
      reply.raw.end();
    }
  });

  app.get("/executions/:id", { preHandler: requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const execution = await prisma.execution.findUnique({ where: { id }, include: { logs: true } });
    if (!execution) return reply.status(404).send({ error: "Execution not found" });
    return reply.send(execution);
  });

  app.get("/executions/:id/logs", { preHandler: requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const logs = await prisma.executionLog.findMany({ where: { executionId: id }, orderBy: { createdAt: "asc" } });
    return reply.send(logs);
  });
}
