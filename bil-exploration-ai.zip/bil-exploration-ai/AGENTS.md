# AGENTS.md — Rules for AI Coding Agents on BIL EXPLORATION AI

## Core principle
The platform must stay **provider-agnostic**. Never write code that calls a specific AI provider's SDK/API outside `packages/providers/<provider>/`. Every other part of the codebase (engine, nodes, API, web, CLI) talks only to the `AIProvider` interface in `packages/ai-core`.

## Before implementing anything
1. Read the relevant section of `BIL_EXPLORATION_AI_SPEC.md` first.
2. Identify which package the change belongs in (see repo structure — one concern per package).
3. Define/update the interface or schema before writing implementation.
4. Write or update a test alongside the change.
5. Implement the smallest correct version — do not add configurability, providers, or node types that weren't asked for.

## Hard rules
- Never hardcode an API key, or read one from `process.env` outside `packages/security` / the provider adapter that owns it.
- Never send a decrypted credential to a frontend response.
- Never add a new workflow node type without: input schema, output schema, and an entry in `workflow-nodes`'s registry.
- Never let a code/shell/HTTP node execute without going through the sandbox + permission check in `packages/security`.
- Do not introduce a new service, queue, or infrastructure dependency (Redis, a message broker, a second database) to solve an MVP-stage problem — the in-process engine and Postgres are sufficient until the migration trigger in the spec (§F) is met. Propose it in a doc first if you think it's needed.
- Do not rewrite the workflow engine's DAG logic to fix a node-level bug — fix the node.
- Keep `apps/web`, `apps/api`, `apps/cli` free of business logic that belongs in `packages/*` — they are thin clients over the packages.

## When adding a new AI provider
1. Create `packages/providers/<name>/`.
2. Implement only the `AIProvider` methods it actually supports; mark unsupported capabilities in its `capabilities` metadata rather than throwing at call time.
3. Add a contract test against the provider's real or sandbox endpoint.
4. Register it — no changes should be needed in `workflow-engine`, `workflow-nodes`, or the API layer.

## When touching the database
- Add a migration; never hand-edit an existing migration that has shipped.
- Credentials table stays encrypted at rest; never add a plaintext key column, even temporarily.

## Documentation
- Any new node type, provider, or API endpoint gets a one-paragraph entry in `docs/`.
- Keep `BIL_EXPLORATION_AI_SPEC.md`'s MVP vs. Future sections accurate — move an item from Future to MVP only when it actually ships.
