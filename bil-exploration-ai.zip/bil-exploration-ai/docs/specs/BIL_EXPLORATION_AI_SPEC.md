# BIL EXPLORATION AI — Spec-Driven Development Document

> *"One Workflow → Multiple AI Providers → One Unified AI Workspace"*

---

## A. Executive Summary

BIL EXPLORATION AI is a multi-AI workflow orchestration platform. Instead of locking users into one chatbot, it lets them connect multiple AI providers (Gemini, Claude, GPT, DeepSeek, OpenRouter, Ollama, custom endpoints), wire them into visual workflows, and run those workflows from a web UI, an API, a CLI, or a VPS. It grows from a personal AI tool into infrastructure other builders can run their own AI pipelines on.

## B. Problem Statement

Builders today are locked into single-provider tools (ChatGPT, Claude.ai, Gemini). Switching providers means rewriting prompts and glue code; combining providers (e.g., "plan with GPT, code with Claude, fact-check with Gemini") means hand-rolled scripts. There's no lightweight, self-hostable, provider-agnostic way to compose multi-model pipelines and run them anywhere — browser, terminal, or server.

## C. Product Vision

BIL EXPLORATION AI becomes the "n8n / Zapier for AI models" — a provider-agnostic orchestration layer other tools and agents are built on top of. Long-term it supports autonomous agents, a workflow marketplace, and self-hosted AI infrastructure for teams.

## D. Core Features

**MVP**
- Auth, dashboard, provider connections (platform key or BYOK)
- Visual workflow builder: input → AI → output nodes, linear chains
- Provider abstraction over Gemini, GPT, Claude, DeepSeek, OpenRouter, Ollama, custom OpenAI-compatible endpoints
- Sequential execution, streaming output, per-node logs (tokens/cost/latency)
- Save/version workflows, run history
- Basic CLI (`bil workflow run`, `bil provider list`)
- Docker + VPS deployment

**Future**
- Parallel/conditional/loop nodes, tool + HTTP + code nodes
- Agent system built on the workflow engine
- AI-to-AI collaboration patterns (plan → review → research → synthesize)
- Model router (auto-pick model by task/cost/latency)
- Teams, shared workspaces, permissions
- Workflow/agent marketplace, plugin system, MCP integration
- RAG, vector DB, browser agents, distributed workers

## E. User Flow

1. Sign up → land on dashboard.
2. Connect a provider: pick platform-managed key or paste own API key (encrypted at rest).
3. Test connection → model list returned, health check passes.
4. Create a workflow: drag Input → AI node(s) → Output; configure each AI node's provider, model, system prompt, temperature.
5. Run with a test input → see streaming output + per-node latency/tokens/cost.
6. Save workflow, copy its ID.
7. Run it later from the CLI or API using that ID.
8. (Future) Invite teammates, share the workflow in a workspace, monitor usage on a dashboard.

## F. System Architecture

**MVP — Modular Monolith** (one deployable API + a thin worker for long jobs; everything else is internal modules, not services):

```mermaid
flowchart TB
    subgraph Client
        Web[Web UI]
        CLI[BIL CLI]
    end
    Web --> API[BIL API — Auth + Workflow API]
    CLI --> API
    API --> Vault[Credential Vault]
    API --> Engine[Workflow Engine]
    Engine --> JobRunner[In-process Job Runner]
    Engine --> Router[AI Router]
    Router --> Gemini
    Router --> OpenAI
    Router --> Anthropic
    Router --> DeepSeek
    Router --> OpenRouter
    Router --> Ollama
    Router --> Custom[Custom OpenAI-compatible]
    API --> PG[(PostgreSQL)]
    Engine --> Storage[(Local Object Storage)]
```

**Future — Distributed** (split out only when the monolith's in-process runner can't keep up — see §Q migration trigger):

```mermaid
flowchart TB
    Web --> Gateway[API Gateway]
    CLI --> Gateway
    Gateway --> Auth[Auth Service]
    Gateway --> WorkflowAPI[Workflow API]
    WorkflowAPI --> Queue[Redis / SQS]
    Queue --> Worker1[Worker 1]
    Queue --> Worker2[Worker 2]
    Queue --> WorkerN[Worker N]
    Worker1 --> AIRouter[AI Router]
    Worker2 --> AIRouter
    AIRouter --> Providers[Provider Adapters]
    WorkflowAPI --> PG[(PostgreSQL)]
    Worker1 --> ObjStore[(Object Storage)]
    Gateway --> Obs[Observability]
```

**Migration trigger:** only split the worker out of the API when you have *sustained* concurrent runs exceeding ~50, or workflows lasting >60s that block the API event loop. Until then, an in-process job runner (see §K) is correct.

## G. Technology Stack

| Layer | Choice | Why |
|---|---|---|
| Web | Next.js + TypeScript + React Flow | Node-based canvas is React Flow's core use case; Next gives SSR + API routes in one deploy |
| API | Node.js (NestJS or Fastify) + TypeScript | Same language as web/CLI = shared types/SDK; huge provider-SDK ecosystem |
| Workflow engine | In-process TS engine (own DAG executor), not a heavyweight workflow framework | Keeps MVP dependency-light; swap in Temporal/BullMQ only when scale demands it |
| DB | PostgreSQL | Relational data (users, workflows, executions) with JSONB for flexible node configs |
| Queue/cache | Redis (only once execution moves out of the request cycle) | Standard, cheap, works for both job queue and rate limiting |
| CLI | Node.js (oclif or a small custom CLI), calls the same API as the web app | No duplicated business logic |
| Secrets | Envelope-encrypted at rest (KMS or libsodium sealed box), decrypted only in the provider layer | Never expose plaintext keys to the frontend |
| Deployment | Docker Compose for MVP/VPS; move to Kubernetes only at real multi-tenant scale | Avoid over-engineering the MVP |

Rationale for not choosing something heavier (e.g., a full microservice mesh, Kafka, or a no-code workflow engine out of the box): the MVP has one team and modest load — a modular monolith with clean internal interfaces (provider layer, engine, node registry) gets 90% of the benefit of microservices with a fraction of the operational cost, and the module boundaries are exactly where you'd cut services later.

## H. Repository Structure

```
bil-exploration-ai/
├── apps/
│   ├── web/            # Next.js + React Flow builder
│   ├── api/             # NestJS/Fastify API (auth, workflow CRUD, execution trigger)
│   ├── worker/           # Split out post-MVP; stub package for now
│   └── cli/              # bil CLI
├── packages/
│   ├── ai-core/          # AIProvider interface, capability types
│   ├── providers/        # openai/ anthropic/ google/ deepseek/ openrouter/ ollama/ base/
│   ├── workflow-engine/  # DAG executor, retry/timeout/branching logic
│   ├── workflow-nodes/   # input/ output/ ai/ tool/ http/ condition/ loop/
│   ├── agent-engine/     # built on workflow-engine, not separate
│   ├── database/         # Prisma schema + migrations
│   ├── auth/
│   ├── security/         # credential vault, sandboxing helpers
│   └── shared/            # shared types, zod schemas
├── infrastructure/
│   ├── docker/
│   ├── nginx/
│   └── deployment/
├── docs/
│   ├── architecture/
│   ├── specs/
│   ├── api/
│   └── workflows/
├── tests/
├── scripts/
├── .env.example
├── docker-compose.yml
├── README.md
└── AGENTS.md
```

## I. Database Schema (core entities)

- **users** (id, email, password_hash, created_at)
- **organizations** / **org_members** (id, name; user_id, org_id, role)
- **projects** (id, org_id, name)
- **ai_providers** (id, key like "google"/"anthropic", display_name, base_url, capabilities jsonb)
- **api_credentials** (id, org_id or user_id, provider_id, encrypted_key, source: platform|byok|env, created_at)
- **ai_models** (id, provider_id, model_key, context_window, capabilities jsonb, cost_input, cost_output)
- **workflows** (id, project_id, name, latest_version_id)
- **workflow_versions** (id, workflow_id, version_number, graph jsonb — nodes + edges, created_at)
- **executions** (id, workflow_version_id, status, started_at, ended_at, triggered_by)
- **execution_logs** (id, execution_id, node_id, provider_id, model_id, input jsonb, output jsonb, tokens_in, tokens_out, cost, latency_ms, error, retry_count)
- **agents** (id, project_id, name, base_workflow_id) — agents are workflows with a goal-loop wrapper, not a separate engine
- **tools** (id, name, type: http|code|search, config jsonb)
- **memories** (id, scope: user|org|agent, key, value jsonb) — for future agent memory/RAG
- **webhooks** (id, workflow_id, url, secret, event_type)

Relationships: org → projects → workflows → versions → executions → logs (1:many down the chain); credentials scoped to org or user, never embedded in workflow_versions.graph itself (nodes reference a credential_id, not a key).

## J. API Design (key endpoints)

```
POST   /auth/signup | /auth/login
GET    /providers                      # list supported providers + capabilities
POST   /providers/:id/credentials       # store BYOK key (encrypted)
POST   /providers/:id/test              # health check + model list

POST   /workflows                       # create
GET    /workflows/:id
PUT    /workflows/:id                   # save new version
POST   /workflows/:id/run               # execute (returns execution_id, streams via SSE/WS)
GET    /executions/:id
GET    /executions/:id/logs

GET    /usage?project_id=...            # tokens/cost dashboard data
POST   /webhooks/:workflow_id           # inbound trigger
```

Streaming: execution results stream over Server-Sent Events (simplest, works through most proxies/VPS setups) with a fallback to polling `/executions/:id`.

## K. Workflow Engine

The engine executes a workflow_version's `graph` (nodes + directed edges) as a DAG:

1. Topologically sort nodes; independent branches run **in parallel** (`Promise.all` per level), dependent nodes run **sequentially**.
2. Each node gets: its config, the outputs of its declared inputs (context object), and a shared `runContext` (variables, memory).
3. AI nodes call the provider through the Router (see §L); other node types (tool/http/condition/loop) execute their own handler.
4. Every node call is wrapped with retry (configurable count/backoff) and timeout; failures either halt the run, retry, or route to an error-handling edge if one exists.
5. Conditional/loop nodes evaluate a small expression against `runContext` to pick the next edge or repeat.
6. Every node execution writes an `execution_logs` row as it completes, and streams a progress event to the client.
7. **MVP runs this in-process** inside the API request/worker thread (with a hard max-duration guard); this is intentionally simple and is the thing to replace with a real queue (§F migration trigger), not the DAG logic itself.

## L. AI Provider Interface

```ts
interface AIProvider {
  id: string;                    // "openai", "anthropic", "google", ...
  chat(req: ChatRequest): Promise<ChatResponse>;
  stream(req: ChatRequest): AsyncIterable<ChatChunk>;
  embed?(req: EmbedRequest): Promise<EmbedResponse>;   // optional capability
  toolCall?(req: ToolCallRequest): Promise<ToolCallResponse>;
  healthCheck(): Promise<{ ok: boolean; latencyMs: number }>;
  listModels(): Promise<ModelInfo[]>;
  estimateCost(usage: TokenUsage, model: string): number;
}
```

Each provider under `packages/providers/<name>` implements only the methods it actually supports (an Ollama adapter has no `estimateCost` that matters; a non-vision model reports that in `capabilities`, not by throwing at runtime). The Router (`ai-core`) resolves `provider + model` → provider instance, applies the resolved credential (platform key, BYOK, or local endpoint), and normalizes responses to one internal `ChatResponse` shape so nodes never touch provider-specific payloads directly. Adding a provider means adding one adapter folder — no changes to the engine, nodes, or API.

## M. CLI Architecture

```
User → BIL CLI → BIL API → Workflow Engine → AI Router → Providers
```

The CLI is a thin client: it authenticates once (stored token in `~/.bil/config`), then every command (`bil workflow run <id> --input "..."`, `bil provider test`, `bil logs`) is a call to the same REST/SSE API the web app uses. No business logic lives in the CLI — this keeps web, API, and CLI in permanent sync and means a VPS with just the CLI installed is a full client, no local engine needed.

## N. VPS Architecture

```
Ubuntu VPS
└── Docker Compose
    ├── bil-web        (Next.js)
    ├── bil-api         (Node API + in-process engine for MVP)
    ├── postgres
    ├── redis            (added when worker split happens)
    └── nginx            (reverse proxy + TLS via certbot)
```

MVP ships as a single `docker-compose.yml`; a user can run BIL EXPLORATION AI fully self-hosted on one VPS. Horizontal scaling later means: move the engine into `apps/worker`, add Redis-backed queue, and run N worker containers behind the same API — no schema or node-type changes required.

## O. Security Model

- **Credentials**: BYOK and platform keys stored encrypted (envelope encryption); decrypted only inside the provider adapter process, never sent to the frontend, never logged.
- **AuthN/Z**: session or JWT auth; org/project-scoped authorization on every workflow and credential.
- **Sandboxing**: any node that runs code, shell commands, or arbitrary HTTP requests runs in a restricted sandbox (no filesystem/network access beyond an allowlist) with explicit per-workflow permission grants — off by default.
- **SSRF protection**: HTTP/tool nodes validate and restrict target URLs (block internal IP ranges, require allowlisted schemes).
- **Rate limiting** on API and per-provider call limits to control cost blast-radius from a runaway loop node.
- **Audit logs** for credential access, workflow runs, and permission changes.
- **Tenant isolation**: org_id scoping enforced at the query layer, not just the API layer.

## P. Testing Strategy

- **Unit**: provider adapters (mocked HTTP), engine DAG logic, node handlers.
- **Integration**: workflow run end-to-end against a mock provider server (no real API cost).
- **Provider tests**: contract tests per adapter against provider sandbox/test endpoints where available.
- **Workflow tests**: golden-file tests for a handful of representative workflows (linear, branching, looping).
- **E2E**: Playwright over the web builder for create → run → view logs.
- **Security tests**: SSRF attempts on HTTP nodes, credential-leak checks (grep responses/logs for key patterns), sandbox escape attempts on code nodes.

## Q. MVP Roadmap (milestones)

1. **Foundation** — auth, DB schema, project/workflow CRUD, empty dashboard.
2. **Provider layer** — implement `AIProvider` interface + Gemini, OpenAI, Anthropic adapters; credential storage; `/providers/test`.
3. **Engine v0** — linear-only DAG executor (input → AI → output), in-process, with execution_logs.
4. **Builder UI** — React Flow canvas for input/AI/output nodes, node config panel, run button with streaming output.
5. **CLI v0** — auth, `workflow run`, `provider list`.
6. **Remaining providers** — DeepSeek, OpenRouter, Ollama, custom OpenAI-compatible.
7. **Docker + VPS** — docker-compose, deployment docs, single-VPS self-host guide.
8. **Usage dashboard** — tokens/cost/latency per workflow.

## R. Future Roadmap

- **Phase 1** Foundation → **Phase 2** Multi-AI Workflow (branching/loops/tools) → **Phase 3** AI Agents (agent-engine on top of workflow-engine) → **Phase 4** CLI + VPS hardening → **Phase 5** Marketplace (workflows/agents) → **Phase 6** Team Collaboration (shared workspaces, permissions) → **Phase 7** Enterprise (SSO, dedicated infra, audit) → **Phase 8** Self-hosted AI infrastructure (worker split, GPU/local model support) → **Phase 9** Autonomous AI ecosystem (multi-agent collaboration, RAG, browser/coding/DevOps agents).

---

*See `AGENTS.md` for rules governing AI coding agents working in this repository.*
