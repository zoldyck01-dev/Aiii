// packages/workflow-engine/src/executor.ts
import type { WorkflowGraph, NodeExecutionResult, ExecutionResult, WorkflowNode } from "./graph.js";
import type { NodeRegistry, NodeExecutionContext } from "./node-handler.js";

export interface ExecutorOptions {
  maxRetries?: number;      // per-node default, a node's own config can override
  nodeTimeoutMs?: number;   // hard cap per node call
  onNodeStart?: (node: WorkflowNode) => void;
  onNodeComplete?: (result: NodeExecutionResult) => void;
}

/**
 * Executes a WorkflowGraph as a DAG. Nodes with no unmet dependency run
 * together (one "level"); each level completes before the next starts.
 * This is the MVP's in-process runner — see the spec (§F) for when to
 * replace this call site with a real queue, without touching this logic.
 */
export class WorkflowExecutor {
  constructor(private registry: NodeRegistry, private options: ExecutorOptions = {}) {}

  async run(
    executionId: string,
    graph: WorkflowGraph,
    initialInput: unknown,
    scope: { orgId?: string; userId?: string } = {}
  ): Promise<ExecutionResult> {
    const levels = topoLevels(graph);
    const nodeById = new Map(graph.nodes.map((n) => [n.id, n]));
    const outputs = new Map<string, unknown>();
    const results: NodeExecutionResult[] = [];
    const runVars: Record<string, unknown> = {};
    const skipped = new Set<string>();

    for (const level of levels) {
      const levelResults = await Promise.all(
        level.map(async (nodeId) => {
          const node = nodeById.get(nodeId)!;

          if (skipped.has(nodeId)) return null;

          const incomingEdges = graph.edges.filter((e) => e.to === nodeId);
          const inputs: Record<string, unknown> = {};
          if (incomingEdges.length === 0) {
            inputs["__initial__"] = initialInput;
          } else {
            for (const edge of incomingEdges) inputs[edge.from] = outputs.get(edge.from);
          }

          this.options.onNodeStart?.(node);
          const result = await this.runNodeWithRetry(node, { runVars, inputs, ...scope });
          this.options.onNodeComplete?.(result);
          results.push(result);

          if (result.status === "success") {
            outputs.set(nodeId, result.output);
          } else {
            // downstream nodes with no other path in become unreachable
            for (const edge of graph.edges.filter((e) => e.from === nodeId)) {
              skipped.add(edge.to);
            }
          }
          return result;
        })
      );
      void levelResults;
    }

    const hasError = results.some((r) => r.status === "error");
    const terminalNodeIds = graph.nodes
      .filter((n) => !graph.edges.some((e) => e.from === n.id))
      .map((n) => n.id);
    const finalOutput =
      terminalNodeIds.length === 1
        ? outputs.get(terminalNodeIds[0])
        : Object.fromEntries(terminalNodeIds.map((id) => [id, outputs.get(id)]));

    return {
      executionId,
      status: hasError ? (results.some((r) => r.status === "success") ? "partial" : "error") : "success",
      nodeResults: results,
      finalOutput,
    };
  }

  private async runNodeWithRetry(
    node: WorkflowNode,
    ctx: NodeExecutionContext
  ): Promise<NodeExecutionResult> {
    const maxRetries = (node.config.maxRetries as number) ?? this.options.maxRetries ?? 1;
    const timeoutMs = (node.config.timeoutMs as number) ?? this.options.nodeTimeoutMs ?? 60_000;
    const handler = this.registry.get(node.type);

    let lastError: string | undefined;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const start = Date.now();
      try {
        const result = await withTimeout(handler.execute(node, ctx), timeoutMs);
        return {
          nodeId: node.id,
          status: "success",
          output: result.output,
          tokensIn: result.tokensIn,
          tokensOut: result.tokensOut,
          costUsd: result.costUsd,
          latencyMs: Date.now() - start,
          retryCount: attempt,
        };
      } catch (err) {
        lastError = (err as Error).message;
        if (attempt === maxRetries) {
          return {
            nodeId: node.id,
            status: "error",
            error: lastError,
            latencyMs: Date.now() - start,
            retryCount: attempt,
          };
        }
        await sleep(backoffMs(attempt));
      }
    }
    // unreachable, satisfies TS control-flow analysis
    return { nodeId: node.id, status: "error", error: lastError, latencyMs: 0, retryCount: maxRetries };
  }
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(`Node timed out after ${ms}ms`)), ms)),
  ]);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function backoffMs(attempt: number): number {
  return Math.min(1000 * 2 ** attempt, 10_000);
}

/**
 * Groups node ids into execution levels via Kahn's algorithm — each level
 * is a batch of nodes whose dependencies are all in earlier levels, so
 * everything inside one level can run in parallel with Promise.all.
 */
function topoLevels(graph: WorkflowGraph): string[][] {
  const inDegree = new Map<string, number>();
  const outEdges = new Map<string, string[]>();
  for (const node of graph.nodes) {
    inDegree.set(node.id, 0);
    outEdges.set(node.id, []);
  }
  for (const edge of graph.edges) {
    inDegree.set(edge.to, (inDegree.get(edge.to) ?? 0) + 1);
    outEdges.get(edge.from)?.push(edge.to);
  }

  const levels: string[][] = [];
  let frontier = [...inDegree.entries()].filter(([, deg]) => deg === 0).map(([id]) => id);
  const visited = new Set<string>();

  while (frontier.length > 0) {
    levels.push(frontier);
    const next: string[] = [];
    for (const id of frontier) {
      visited.add(id);
      for (const target of outEdges.get(id) ?? []) {
        const remaining = (inDegree.get(target) ?? 0) - 1;
        inDegree.set(target, remaining);
        if (remaining === 0) next.push(target);
      }
    }
    frontier = next;
  }

  if (visited.size !== graph.nodes.length) {
    throw new Error("Workflow graph contains a cycle or an unreachable node — cannot execute");
  }
  return levels;
}
