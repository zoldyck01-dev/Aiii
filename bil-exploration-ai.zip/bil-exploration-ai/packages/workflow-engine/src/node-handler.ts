// packages/workflow-engine/src/node-handler.ts
import type { WorkflowNode } from "./graph.js";

/**
 * Context passed into every node handler at execution time.
 * runVars: mutable key/value bag shared across the whole execution
 *          (condition/loop nodes read and write it).
 * inputs: the outputs of this node's upstream nodes, keyed by node id.
 */
export interface NodeExecutionContext {
  runVars: Record<string, unknown>;
  inputs: Record<string, unknown>;
  orgId?: string;
  userId?: string;
}

export interface NodeHandlerResult {
  output: unknown;
  tokensIn?: number;
  tokensOut?: number;
  costUsd?: number;
  /** For condition/loop nodes: which outgoing edge(s) to follow next. Omit to follow all. */
  nextEdgeTags?: string[];
}

export interface NodeHandler {
  type: string;
  execute(node: WorkflowNode, ctx: NodeExecutionContext): Promise<NodeHandlerResult>;
}

export class NodeRegistry {
  private handlers = new Map<string, NodeHandler>();

  register(handler: NodeHandler): void {
    this.handlers.set(handler.type, handler);
  }

  get(type: string): NodeHandler {
    const handler = this.handlers.get(type);
    if (!handler) throw new Error(`No node handler registered for type "${type}"`);
    return handler;
  }
}
