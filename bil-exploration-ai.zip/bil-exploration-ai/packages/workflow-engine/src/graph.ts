// packages/workflow-engine/src/graph.ts
// The shape stored in workflow_versions.graph (jsonb) in the database.

export type NodeType = "input" | "output" | "ai" | "tool" | "http" | "condition" | "loop";

export interface WorkflowNode {
  id: string;
  type: NodeType;
  name: string;
  // Node-specific config — validated by that node type's handler, not here.
  config: Record<string, unknown>;
}

export interface WorkflowEdge {
  from: string; // node id
  to: string;   // node id
  // Optional: only taken when a condition node's expression matches this value
  when?: string;
}

export interface WorkflowGraph {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
}

export interface NodeExecutionResult {
  nodeId: string;
  status: "success" | "error";
  output?: unknown;
  error?: string;
  tokensIn?: number;
  tokensOut?: number;
  costUsd?: number;
  latencyMs: number;
  retryCount: number;
}

export interface ExecutionResult {
  executionId: string;
  status: "success" | "error" | "partial";
  nodeResults: NodeExecutionResult[];
  finalOutput?: unknown;
}
