// packages/ai-core/src/router.ts
import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatChunk,
  ProviderCredential,
} from "./types.js";

export class ProviderNotFoundError extends Error {
  constructor(providerId: string) {
    super(`No AI provider registered with id "${providerId}"`);
    this.name = "ProviderNotFoundError";
  }
}

export class CapabilityNotSupportedError extends Error {
  constructor(providerId: string, capability: string) {
    super(`Provider "${providerId}" does not support capability "${capability}"`);
    this.name = "CapabilityNotSupportedError";
  }
}

/**
 * A function that resolves the credential to use for a given provider,
 * for a given org/user. Implemented by the API layer (talks to the
 * encrypted credential vault) — the router never touches storage directly.
 */
export type CredentialResolver = (
  providerId: string,
  scope: { orgId?: string; userId?: string }
) => Promise<ProviderCredential>;

export class AIRouter {
  private providers = new Map<string, AIProvider>();

  constructor(private resolveCredential: CredentialResolver) {}

  register(provider: AIProvider): void {
    this.providers.set(provider.id, provider);
  }

  private get(providerId: string): AIProvider {
    const provider = this.providers.get(providerId);
    if (!provider) throw new ProviderNotFoundError(providerId);
    return provider;
  }

  async chat(
    providerId: string,
    req: ChatRequest,
    scope: { orgId?: string; userId?: string }
  ): Promise<ChatResponse> {
    const provider = this.get(providerId);
    const credential = await this.resolveCredential(providerId, scope);
    return provider.chat(req, credential);
  }

  async *stream(
    providerId: string,
    req: ChatRequest,
    scope: { orgId?: string; userId?: string }
  ): AsyncIterable<ChatChunk> {
    const provider = this.get(providerId);
    const credential = await this.resolveCredential(providerId, scope);
    yield* provider.stream(req, credential);
  }

  async healthCheck(providerId: string, scope: { orgId?: string; userId?: string }) {
    const provider = this.get(providerId);
    const credential = await this.resolveCredential(providerId, scope);
    return provider.healthCheck(credential);
  }

  async listModels(providerId: string, scope: { orgId?: string; userId?: string }) {
    const provider = this.get(providerId);
    const credential = await this.resolveCredential(providerId, scope);
    return provider.listModels(credential);
  }

  listRegisteredProviders(): string[] {
    return [...this.providers.keys()];
  }
}
