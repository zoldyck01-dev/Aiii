// packages/ai-core/src/types.ts
// Shared types for the provider-agnostic AI layer.
// Nothing in here may reference a specific vendor SDK or API shape —
// that translation lives entirely inside packages/providers/<name>.

export type ChatRole = "system" | "user" | "assistant" | "tool";

export interface ChatMessage {
  role: ChatRole;
  content: string;
  // Optional: for tool-calling round trips
  toolCallId?: string;
  name?: string;
}

export interface ChatRequest {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  tools?: ToolDefinition[];
  metadata?: Record<string, unknown>;
}

export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
}

export interface ChatResponse {
  content: string;
  usage: TokenUsage;
  model: string;
  finishReason: "stop" | "length" | "tool_call" | "error";
  toolCalls?: ToolCall[];
  raw?: unknown; // original provider payload, for debugging only — never persisted verbatim to logs shown to other tenants
}

export interface ChatChunk {
  delta: string;
  done: boolean;
  usage?: TokenUsage; // present on the final chunk, if the provider reports it
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>; // JSON schema
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface ToolCallRequest extends ChatRequest {
  tools: ToolDefinition[];
}

export interface ToolCallResponse extends ChatResponse {
  toolCalls: ToolCall[];
}

export interface EmbedRequest {
  model: string;
  input: string | string[];
}

export interface EmbedResponse {
  embeddings: number[][];
  usage: TokenUsage;
}

export interface ModelInfo {
  id: string;
  displayName: string;
  contextWindow: number;
  capabilities: ModelCapabilities;
  costPer1kInput?: number;  // USD, undefined for free/local models
  costPer1kOutput?: number;
}

export interface ModelCapabilities {
  chat: boolean;
  stream: boolean;
  vision: boolean;
  toolCalling: boolean;
  embed: boolean;
}

export interface HealthCheckResult {
  ok: boolean;
  latencyMs: number;
  error?: string;
}

export interface ProviderCredential {
  // Resolved by the credential vault before reaching the provider adapter.
  // The adapter never touches the database or encryption layer directly.
  apiKey?: string;
  baseUrl?: string; // for custom OpenAI-compatible / self-hosted endpoints
}

/**
 * The single contract every AI provider adapter must implement.
 * Implement only what the provider actually supports — report the
 * rest as `false` in listModels()' capabilities rather than throwing
 * at call time.
 */
export interface AIProvider {
  readonly id: string; // "openai" | "anthropic" | "google" | "deepseek" | "openrouter" | "ollama" | "custom"

  chat(req: ChatRequest, credential: ProviderCredential): Promise<ChatResponse>;

  stream(req: ChatRequest, credential: ProviderCredential): AsyncIterable<ChatChunk>;

  embed?(req: EmbedRequest, credential: ProviderCredential): Promise<EmbedResponse>;

  toolCall?(req: ToolCallRequest, credential: ProviderCredential): Promise<ToolCallResponse>;

  healthCheck(credential: ProviderCredential): Promise<HealthCheckResult>;

  listModels(credential?: ProviderCredential): Promise<ModelInfo[]>;

  estimateCost(usage: TokenUsage, modelId: string): number; // returns 0 for free/local providers
}
