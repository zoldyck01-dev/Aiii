// packages/providers/src/anthropic/index.ts
import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatChunk,
  ModelInfo,
  HealthCheckResult,
  ProviderCredential,
  TokenUsage,
} from "@bil/ai-core";
import { providerFetch } from "../base/http.js";

const DEFAULT_BASE_URL = "https://api.anthropic.com/v1";
const ANTHROPIC_VERSION = "2023-06-01";

const PRICING: Record<string, { input: number; output: number }> = {
  "claude-sonnet-4-6": { input: 0.003, output: 0.015 },
  "claude-haiku-4-5-20251001": { input: 0.0008, output: 0.004 },
};

// Anthropic's messages API takes system prompt separately from the
// message list — this adapter translates our unified ChatMessage[]
// shape into that, so nothing outside this file needs to know.
function splitSystem(messages: ChatRequest["messages"]) {
  const system = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n");
  const rest = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content }));
  return { system, rest };
}

export class AnthropicProvider implements AIProvider {
  readonly id = "anthropic";

  private baseUrl(credential: ProviderCredential) {
    return credential.baseUrl ?? DEFAULT_BASE_URL;
  }

  private headers(credential: ProviderCredential) {
    if (!credential.apiKey) throw new Error("Anthropic provider requires an apiKey credential");
    return {
      "Content-Type": "application/json",
      "x-api-key": credential.apiKey,
      "anthropic-version": ANTHROPIC_VERSION,
    };
  }

  async chat(req: ChatRequest, credential: ProviderCredential): Promise<ChatResponse> {
    const { system, rest } = splitSystem(req.messages);
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/messages`, {
      method: "POST",
      headers: this.headers(credential),
      body: JSON.stringify({
        model: req.model,
        system: system || undefined,
        messages: rest,
        max_tokens: req.maxTokens ?? 1024,
        temperature: req.temperature,
      }),
    });
    const data = await res.json();
    const text = (data.content ?? []).filter((b: { type: string }) => b.type === "text").map((b: { text: string }) => b.text).join("");
    return {
      content: text,
      usage: {
        inputTokens: data.usage?.input_tokens ?? 0,
        outputTokens: data.usage?.output_tokens ?? 0,
      },
      model: data.model ?? req.model,
      finishReason: data.stop_reason === "max_tokens" ? "length" : "stop",
      raw: data,
    };
  }

  async *stream(req: ChatRequest, credential: ProviderCredential): AsyncIterable<ChatChunk> {
    const { system, rest } = splitSystem(req.messages);
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/messages`, {
      method: "POST",
      headers: this.headers(credential),
      body: JSON.stringify({
        model: req.model,
        system: system || undefined,
        messages: rest,
        max_tokens: req.maxTokens ?? 1024,
        temperature: req.temperature,
        stream: true,
      }),
    });
    if (!res.body) return;
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        try {
          const json = JSON.parse(trimmed.slice(5).trim());
          if (json.type === "content_block_delta" && json.delta?.text) {
            yield { delta: json.delta.text, done: false };
          }
          if (json.type === "message_stop") {
            yield { delta: "", done: true };
            return;
          }
        } catch {
          // ignore malformed SSE chunk
        }
      }
    }
    yield { delta: "", done: true };
  }

  async healthCheck(credential: ProviderCredential): Promise<HealthCheckResult> {
    const start = Date.now();
    try {
      await this.chat(
        { model: "claude-haiku-4-5-20251001", messages: [{ role: "user", content: "ping" }], maxTokens: 1 },
        credential
      );
      return { ok: true, latencyMs: Date.now() - start };
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - start, error: (err as Error).message };
    }
  }

  async listModels(): Promise<ModelInfo[]> {
    // Anthropic has no public "list models" endpoint at present — maintain
    // a small static registry here and update as new models ship.
    return [
      {
        id: "claude-sonnet-4-6",
        displayName: "Claude Sonnet 4.6",
        contextWindow: 200_000,
        capabilities: { chat: true, stream: true, vision: true, toolCalling: true, embed: false },
        costPer1kInput: PRICING["claude-sonnet-4-6"].input,
        costPer1kOutput: PRICING["claude-sonnet-4-6"].output,
      },
      {
        id: "claude-haiku-4-5-20251001",
        displayName: "Claude Haiku 4.5",
        contextWindow: 200_000,
        capabilities: { chat: true, stream: true, vision: true, toolCalling: true, embed: false },
        costPer1kInput: PRICING["claude-haiku-4-5-20251001"].input,
        costPer1kOutput: PRICING["claude-haiku-4-5-20251001"].output,
      },
    ];
  }

  estimateCost(usage: TokenUsage, modelId: string): number {
    const pricing = PRICING[modelId];
    if (!pricing) return 0;
    return (usage.inputTokens / 1000) * pricing.input + (usage.outputTokens / 1000) * pricing.output;
  }
}
