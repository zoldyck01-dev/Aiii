// packages/providers/src/index.ts
import type { AIProvider } from "@bil/ai-core";
import { OpenAIProvider } from "./openai/index.js";
import { AnthropicProvider } from "./anthropic/index.js";
import { GoogleProvider } from "./google/index.js";
import { OllamaProvider } from "./ollama/index.js";
import { createOpenAICompatibleProvider, DEEPSEEK_BASE_URL, OPENROUTER_BASE_URL } from "./openai/compatible.js";

export { OpenAIProvider } from "./openai/index.js";
export { AnthropicProvider } from "./anthropic/index.js";
export { GoogleProvider } from "./google/index.js";
export { OllamaProvider } from "./ollama/index.js";
export { createOpenAICompatibleProvider } from "./openai/compatible.js";

/** All providers that ship with BIL EXPLORATION AI out of the box. */
export function builtInProviders(): AIProvider[] {
  return [
    new OpenAIProvider(),
    new AnthropicProvider(),
    new GoogleProvider(),
    new OllamaProvider(),
    createOpenAICompatibleProvider({ id: "deepseek", defaultBaseUrl: DEEPSEEK_BASE_URL }),
    createOpenAICompatibleProvider({ id: "openrouter", defaultBaseUrl: OPENROUTER_BASE_URL }),
  ];
}
