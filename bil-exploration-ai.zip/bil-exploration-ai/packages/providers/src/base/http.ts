// packages/providers/src/base/http.ts
// Small shared fetch helper so every adapter handles timeouts/errors the same way.

export class ProviderHttpError extends Error {
  constructor(
    public providerId: string,
    public status: number,
    public body: string
  ) {
    super(`[${providerId}] HTTP ${status}: ${body.slice(0, 300)}`);
    this.name = "ProviderHttpError";
  }
}

export async function providerFetch(
  providerId: string,
  url: string,
  init: RequestInit,
  timeoutMs = 60_000
): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new ProviderHttpError(providerId, res.status, body);
    }
    return res;
  } finally {
    clearTimeout(timeout);
  }
}
