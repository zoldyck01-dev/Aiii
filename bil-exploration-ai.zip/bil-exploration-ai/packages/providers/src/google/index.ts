// packages/providers/src/google/index.ts
import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatChunk,
  ModelInfo,
  HealthCheckResult,
  ProviderCredential,
  TokenUsage,
} from "@bil/ai-core";
import { providerFetch } from "../base/http.js";

const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";

const PRICING: Record<string, { input: number; output: number }> = {
  "gemini-2.5-pro": { input: 0.00125, output: 0.005 },
  "gemini-2.5-flash": { input: 0.000075, output: 0.0003 },
};

function toGeminiContents(messages: ChatRequest["messages"]) {
  // Gemini has no "system" role in the contents array — system
  // instructions go in a separate field, handled by the caller below.
  return messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));
}

export class GoogleProvider implements AIProvider {
  readonly id = "google";

  private baseUrl(credential: ProviderCredential) {
    return credential.baseUrl ?? DEFAULT_BASE_URL;
  }

  private key(credential: ProviderCredential) {
    if (!credential.apiKey) throw new Error("Google provider requires an apiKey credential");
    return credential.apiKey;
  }

  private buildBody(req: ChatRequest) {
    const systemText = req.messages.filter((m) => m.role === "system").map((m) => m.content).join("\n");
    return {
      contents: toGeminiContents(req.messages),
      systemInstruction: systemText ? { parts: [{ text: systemText }] } : undefined,
      generationConfig: {
        temperature: req.temperature,
        maxOutputTokens: req.maxTokens,
      },
    };
  }

  async chat(req: ChatRequest, credential: ProviderCredential): Promise<ChatResponse> {
    const res = await providerFetch(
      this.id,
      `${this.baseUrl(credential)}/models/${req.model}:generateContent?key=${this.key(credential)}`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(this.buildBody(req)) }
    );
    const data = await res.json();
    const candidate = data.candidates?.[0];
    const text = (candidate?.content?.parts ?? []).map((p: { text?: string }) => p.text ?? "").join("");
    return {
      content: text,
      usage: {
        inputTokens: data.usageMetadata?.promptTokenCount ?? 0,
        outputTokens: data.usageMetadata?.candidatesTokenCount ?? 0,
      },
      model: req.model,
      finishReason: candidate?.finishReason === "MAX_TOKENS" ? "length" : "stop",
      raw: data,
    };
  }

  async *stream(req: ChatRequest, credential: ProviderCredential): AsyncIterable<ChatChunk> {
    const res = await providerFetch(
      this.id,
      `${this.baseUrl(credential)}/models/${req.model}:streamGenerateContent?alt=sse&key=${this.key(credential)}`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(this.buildBody(req)) }
    );
    if (!res.body) return;
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        try {
          const json = JSON.parse(trimmed.slice(5).trim());
          const delta = (json.candidates?.[0]?.content?.parts ?? [])
            .map((p: { text?: string }) => p.text ?? "")
            .join("");
          if (delta) yield { delta, done: false };
        } catch {
          // ignore malformed SSE chunk
        }
      }
    }
    yield { delta: "", done: true };
  }

  async healthCheck(credential: ProviderCredential): Promise<HealthCheckResult> {
    const start = Date.now();
    try {
      await providerFetch(this.id, `${this.baseUrl(credential)}/models?key=${this.key(credential)}`, {});
      return { ok: true, latencyMs: Date.now() - start };
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - start, error: (err as Error).message };
    }
  }

  async listModels(credential: ProviderCredential): Promise<ModelInfo[]> {
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/models?key=${this.key(credential)}`, {});
    const data = await res.json();
    return (data.models ?? [])
      .filter((m: { name: string }) => m.name.includes("gemini"))
      .map((m: { name: string; inputTokenLimit?: number }) => {
        const id = m.name.replace("models/", "");
        return {
          id,
          displayName: id,
          contextWindow: m.inputTokenLimit ?? 1_000_000,
          capabilities: { chat: true, stream: true, vision: true, toolCalling: true, embed: false },
          costPer1kInput: PRICING[id]?.input,
          costPer1kOutput: PRICING[id]?.output,
        };
      });
  }

  estimateCost(usage: TokenUsage, modelId: string): number {
    const pricing = PRICING[modelId];
    if (!pricing) return 0;
    return (usage.inputTokens / 1000) * pricing.input + (usage.outputTokens / 1000) * pricing.output;
  }
}
