// packages/providers/src/openai/compatible.ts
// DeepSeek, OpenRouter, and any "OpenAI-compatible" endpoint (including a
// user's own self-hosted gateway) all speak the same /chat/completions
// shape as OpenAI. Rather than duplicating the whole adapter, this factory
// produces a provider instance with a different id/base URL — this is the
// "add a provider without touching the engine" path for compatible APIs.
import { OpenAIProvider } from "./index.js";
import type { AIProvider, ProviderCredential } from "@bil/ai-core";

export function createOpenAICompatibleProvider(opts: {
  id: string;
  defaultBaseUrl: string;
}): AIProvider {
  const inner = new OpenAIProvider();
  return {
    ...inner,
    id: opts.id,
    chat: (req, credential) =>
      inner.chat(req, withDefaultBaseUrl(credential, opts.defaultBaseUrl)),
    stream: (req, credential) =>
      inner.stream(req, withDefaultBaseUrl(credential, opts.defaultBaseUrl)),
    healthCheck: (credential) =>
      inner.healthCheck(withDefaultBaseUrl(credential, opts.defaultBaseUrl)),
    listModels: (credential) =>
      inner.listModels(withDefaultBaseUrl(credential ?? {}, opts.defaultBaseUrl)),
    estimateCost: (usage, modelId) => inner.estimateCost(usage, modelId),
  };
}

function withDefaultBaseUrl(credential: ProviderCredential, defaultBaseUrl: string): ProviderCredential {
  return { ...credential, baseUrl: credential.baseUrl ?? defaultBaseUrl };
}

export const DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1";
export const OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1";
