// packages/providers/src/openai/index.ts
import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatChunk,
  ModelInfo,
  HealthCheckResult,
  ProviderCredential,
  TokenUsage,
} from "@bil/ai-core";
import { providerFetch } from "../base/http.js";

const DEFAULT_BASE_URL = "https://api.openai.com/v1";

// USD per 1k tokens — keep in sync with OpenAI pricing; adjust as needed.
const PRICING: Record<string, { input: number; output: number }> = {
  "gpt-4o": { input: 0.0025, output: 0.01 },
  "gpt-4o-mini": { input: 0.00015, output: 0.0006 },
};

export class OpenAIProvider implements AIProvider {
  readonly id = "openai";

  private baseUrl(credential: ProviderCredential) {
    return credential.baseUrl ?? DEFAULT_BASE_URL;
  }

  private headers(credential: ProviderCredential) {
    if (!credential.apiKey) throw new Error("OpenAI provider requires an apiKey credential");
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${credential.apiKey}`,
    };
  }

  async chat(req: ChatRequest, credential: ProviderCredential): Promise<ChatResponse> {
    const res = await providerFetch(
      this.id,
      `${this.baseUrl(credential)}/chat/completions`,
      {
        method: "POST",
        headers: this.headers(credential),
        body: JSON.stringify({
          model: req.model,
          messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
          temperature: req.temperature,
          max_tokens: req.maxTokens,
        }),
      }
    );
    const data = await res.json();
    const choice = data.choices?.[0];
    return {
      content: choice?.message?.content ?? "",
      usage: {
        inputTokens: data.usage?.prompt_tokens ?? 0,
        outputTokens: data.usage?.completion_tokens ?? 0,
      },
      model: data.model ?? req.model,
      finishReason: choice?.finish_reason === "length" ? "length" : "stop",
      raw: data,
    };
  }

  async *stream(req: ChatRequest, credential: ProviderCredential): AsyncIterable<ChatChunk> {
    const res = await providerFetch(
      this.id,
      `${this.baseUrl(credential)}/chat/completions`,
      {
        method: "POST",
        headers: this.headers(credential),
        body: JSON.stringify({
          model: req.model,
          messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
          temperature: req.temperature,
          max_tokens: req.maxTokens,
          stream: true,
        }),
      }
    );
    if (!res.body) return;
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === "[DONE]") {
          yield { delta: "", done: true };
          return;
        }
        try {
          const json = JSON.parse(payload);
          const delta = json.choices?.[0]?.delta?.content ?? "";
          if (delta) yield { delta, done: false };
        } catch {
          // ignore malformed SSE chunk
        }
      }
    }
    yield { delta: "", done: true };
  }

  async healthCheck(credential: ProviderCredential): Promise<HealthCheckResult> {
    const start = Date.now();
    try {
      await providerFetch(this.id, `${this.baseUrl(credential)}/models`, {
        headers: this.headers(credential),
      });
      return { ok: true, latencyMs: Date.now() - start };
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - start, error: (err as Error).message };
    }
  }

  async listModels(credential: ProviderCredential): Promise<ModelInfo[]> {
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/models`, {
      headers: this.headers(credential),
    });
    const data = await res.json();
    return (data.data ?? [])
      .filter((m: { id: string }) => m.id.startsWith("gpt-"))
      .map((m: { id: string }) => ({
        id: m.id,
        displayName: m.id,
        contextWindow: 128_000,
        capabilities: { chat: true, stream: true, vision: m.id.includes("gpt-4o"), toolCalling: true, embed: false },
        costPer1kInput: PRICING[m.id]?.input,
        costPer1kOutput: PRICING[m.id]?.output,
      }));
  }

  estimateCost(usage: TokenUsage, modelId: string): number {
    const pricing = PRICING[modelId];
    if (!pricing) return 0;
    return (usage.inputTokens / 1000) * pricing.input + (usage.outputTokens / 1000) * pricing.output;
  }
}
