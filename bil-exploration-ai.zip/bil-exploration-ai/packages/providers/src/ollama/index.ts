// packages/providers/src/ollama/index.ts
import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatChunk,
  ModelInfo,
  HealthCheckResult,
  ProviderCredential,
  TokenUsage,
} from "@bil/ai-core";
import { providerFetch } from "../base/http.js";

const DEFAULT_BASE_URL = "http://localhost:11434";

export class OllamaProvider implements AIProvider {
  readonly id = "ollama";

  private baseUrl(credential: ProviderCredential) {
    // Local/self-hosted — baseUrl is required in practice (points at the
    // user's own Ollama instance), defaulted here for convenience only.
    return credential.baseUrl ?? DEFAULT_BASE_URL;
  }

  async chat(req: ChatRequest, credential: ProviderCredential): Promise<ChatResponse> {
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: req.model,
        messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
        options: { temperature: req.temperature },
        stream: false,
      }),
    });
    const data = await res.json();
    return {
      content: data.message?.content ?? "",
      usage: {
        inputTokens: data.prompt_eval_count ?? 0,
        outputTokens: data.eval_count ?? 0,
      },
      model: req.model,
      finishReason: "stop",
      raw: data,
    };
  }

  async *stream(req: ChatRequest, credential: ProviderCredential): AsyncIterable<ChatChunk> {
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: req.model,
        messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
        options: { temperature: req.temperature },
        stream: true,
      }),
    });
    if (!res.body) return;
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n").filter(Boolean);
      buffer = "";
      for (const line of lines) {
        try {
          const json = JSON.parse(line);
          if (json.message?.content) yield { delta: json.message.content, done: false };
          if (json.done) {
            yield { delta: "", done: true };
            return;
          }
        } catch {
          buffer += line; // incomplete JSON line, keep for next chunk
        }
      }
    }
  }

  async healthCheck(credential: ProviderCredential): Promise<HealthCheckResult> {
    const start = Date.now();
    try {
      await providerFetch(this.id, `${this.baseUrl(credential)}/api/tags`, {});
      return { ok: true, latencyMs: Date.now() - start };
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - start, error: (err as Error).message };
    }
  }

  async listModels(credential: ProviderCredential): Promise<ModelInfo[]> {
    const res = await providerFetch(this.id, `${this.baseUrl(credential)}/api/tags`, {});
    const data = await res.json();
    return (data.models ?? []).map((m: { name: string }) => ({
      id: m.name,
      displayName: m.name,
      contextWindow: 8192, // unknown per-model without a separate call; conservative default
      capabilities: { chat: true, stream: true, vision: false, toolCalling: false, embed: false },
      // no cost fields — local models are free
    }));
  }

  estimateCost(_usage: TokenUsage, _modelId: string): number {
    return 0; // local inference — no per-token cost
  }
}
