// packages/workflow-nodes/src/input.ts
import type { NodeHandler } from "@bil/workflow-engine";

/** Passes the execution's initial input straight through. */
export const inputNode: NodeHandler = {
  type: "input",
  async execute(_node, ctx) {
    return { output: ctx.inputs["__initial__"] };
  },
};
