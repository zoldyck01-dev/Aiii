// packages/workflow-nodes/src/ai.ts
import type { NodeHandler } from "@bil/workflow-engine";
import type { AIRouter, ChatMessage } from "@bil/ai-core";

export interface AINodeConfig {
  provider: string;       // "openai" | "anthropic" | "google" | "deepseek" | "openrouter" | "ollama"
  model: string;
  systemPrompt?: string;
  temperature?: number;
  maxTokens?: number;
  /** Which upstream node's output to use as the user message; defaults to the first input found. */
  inputFrom?: string;
}

/**
 * Creates the "ai" node handler bound to a given AIRouter. Factory pattern
 * (rather than a module-level singleton) keeps the node package free of
 * any concrete router/credential wiring — the API app owns that.
 */
export function createAINodeHandler(router: AIRouter): NodeHandler {
  return {
    type: "ai",
    async execute(node, ctx) {
      const config = node.config as unknown as AINodeConfig;
      const upstreamValue = config.inputFrom
        ? ctx.inputs[config.inputFrom]
        : Object.values(ctx.inputs)[0];

      const messages: ChatMessage[] = [];
      if (config.systemPrompt) messages.push({ role: "system", content: config.systemPrompt });
      messages.push({ role: "user", content: stringifyInput(upstreamValue) });

      const response = await router.chat(
        config.provider,
        { model: config.model, messages, temperature: config.temperature, maxTokens: config.maxTokens },
        { orgId: ctx.orgId, userId: ctx.userId }
      );

      return {
        output: response.content,
        tokensIn: response.usage.inputTokens,
        tokensOut: response.usage.outputTokens,
      };
    },
  };
}

function stringifyInput(value: unknown): string {
  if (typeof value === "string") return value;
  return JSON.stringify(value);
}
