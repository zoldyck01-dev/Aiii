// packages/workflow-nodes/src/output.ts
import type { NodeHandler } from "@bil/workflow-engine";

/** Collects whatever its single upstream node produced as the workflow's final output. */
export const outputNode: NodeHandler = {
  type: "output",
  async execute(_node, ctx) {
    const [firstInput] = Object.values(ctx.inputs);
    return { output: firstInput };
  },
};
