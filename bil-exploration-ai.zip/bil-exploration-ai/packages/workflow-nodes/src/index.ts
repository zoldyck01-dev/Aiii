// packages/workflow-nodes/src/index.ts
import { NodeRegistry } from "@bil/workflow-engine";
import type { AIRouter } from "@bil/ai-core";
import { inputNode } from "./input.js";
import { outputNode } from "./output.js";
import { createAINodeHandler } from "./ai.js";

export { inputNode } from "./input.js";
export { outputNode } from "./output.js";
export { createAINodeHandler } from "./ai.js";
export type { AINodeConfig } from "./ai.js";

/** MVP node registry: input, output, ai. Register more as new node types ship. */
export function createDefaultRegistry(router: AIRouter): NodeRegistry {
  const registry = new NodeRegistry();
  registry.register(inputNode);
  registry.register(outputNode);
  registry.register(createAINodeHandler(router));
  return registry;
}
