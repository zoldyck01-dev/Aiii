// packages/database/prisma/seed.ts
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const PROVIDERS = [
  { key: "openai", displayName: "OpenAI", baseUrl: "https://api.openai.com/v1" },
  { key: "anthropic", displayName: "Anthropic", baseUrl: "https://api.anthropic.com/v1" },
  { key: "google", displayName: "Google Gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta" },
  { key: "deepseek", displayName: "DeepSeek", baseUrl: "https://api.deepseek.com/v1" },
  { key: "openrouter", displayName: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1" },
  { key: "ollama", displayName: "Ollama (local)", baseUrl: "http://localhost:11434" },
];

async function main() {
  for (const p of PROVIDERS) {
    await prisma.aiProviderDef.upsert({
      where: { key: p.key },
      update: { displayName: p.displayName, baseUrl: p.baseUrl },
      create: p,
    });
  }
  console.log(`Seeded ${PROVIDERS.length} providers.`);
}

main().finally(() => prisma.$disconnect());
